const socket = io();
let localStream;
let peer = new Peer(undefined, { host: '/', port: '3000', path: '/peerjs' });
const videoContainer = document.getElementById('video-container');
const localVideo = document.getElementById('localVideo');

// Join a room
async function joinRoom() {
  const roomId = document.getElementById('roomId').value;
  localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  localVideo.srcObject = localStream;

  peer.on('open', id => {
    socket.emit('join-room', roomId, id);
  });

  peer.on('call', call => {
    call.answer(localStream);
    const video = document.createElement('video');
    call.on('stream', userVideoStream => addVideoStream(video, userVideoStream));
  });

  socket.on('user-connected', userId => {
    const call = peer.call(userId, localStream);
    const video = document.createElement('video');
    call.on('stream', userVideoStream => addVideoStream(video, userVideoStream));
  });
}

// Toggle audio/video, screen sharing, end call, and messaging
function toggleAudio() {
  localStream.getAudioTracks()[0].enabled = !localStream.getAudioTracks()[0].enabled;
}

function toggleVideo() {
  localStream.getVideoTracks()[0].enabled = !localStream.getVideoTracks()[0].enabled;
}

async function shareScreen() {
  const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
  const videoTrack = screenStream.getVideoTracks()[0];
  videoTrack.onended = () => screenStream.getTracks().forEach(track => track.stop());
}

function sendMessage() {
  const message = document.getElementById('chat-message').value;
  socket.emit('message', message);
  document.getElementById('chat-message').value = '';
}

socket.on('message', message => {
  const msgElement = document.createElement('div');
  msgElement.textContent = message;
  document.getElementById('chat-messages').appendChild(msgElement);
});

function addVideoStream(video, stream) {
  video.srcObject = stream;
  video.addEventListener('loadedmetadata', () => video.play());
  videoContainer.append(video);
}
